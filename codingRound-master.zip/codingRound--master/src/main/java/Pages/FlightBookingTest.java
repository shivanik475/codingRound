package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import utilities.Utility;

public class FlightBookingTest extends Utility{
		WebDriver driver;
		
		@FindBy(id="OneWay")
		WebElement oneWay;
		
		@FindBy(id="FromTag")
		WebElement fromAirport;
		
		@FindBy(xpath="//*[@id='ui-id-1']/li")
		List<WebElement> originOptions;

		@FindBy(id="ToTag")
		WebElement toAirport;
		
		@FindBy(xpath="//*[@id='ui-id-2']/li")
		List<WebElement> destinationOptions;
		
		@FindBy(xpath="//*[@id='DepartDate']")
		WebElement calender;
		
		@FindBy(xpath="//div/table/tbody/tr/td/a[contains(@class,'ui-state-default ui-state-highlight ui-state-active')]")
		WebElement currentDate;
    
		@FindBy(xpath="//*[@id='SearchBtn']")
		WebElement searchButton;
		
		@FindBy(xpath="//*[@class='searchSummary']")
		WebElement summaryPage;
		
		public FlightBookingTest(WebDriver driver) {
			this.driver=driver;
		}
		
	  
		
	    public void testThatResultsAppearForAOneWayJourney() {
	    
	        if(oneWay.isSelected())
	        {

	        fromAirport.clear();
	        fromAirport.sendKeys("Bang");
	        
	        waitFor(5000);

	        //wait for the auto complete options to appear for the origin
	        originOptions.get(0).click();

	        waitFor(2000);
	        toAirport.clear();
	        toAirport.sendKeys("Del");
	        //wait for the auto complete options to appear for the destination

	        waitFor(5000);
	        
	        //select the first item from the destination auto complete list

	        destinationOptions.get(0).click();
	        waitFor(2000);
	        //Select Date
	        calender.click();
	        currentDate.click();
	        waitFor(2000);
	        //Search for Flight
	        searchButton.click();
	        waitFor(10000);
	        try{
	        Assert.assertTrue(summaryPage.getSize()!=null);
	        System.out.print("TC Pass");
	        }
	        catch (Exception e) {
				e.printStackTrace();
			}

	        }

	    }
	   
}
