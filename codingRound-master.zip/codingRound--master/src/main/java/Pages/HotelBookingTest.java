package Pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import utilities.Utility;

public class HotelBookingTest extends Utility {
	
		WebDriver driver;

	    @FindBy(xpath="//*[@id='Home']/div/aside[1]/nav/ul[1]/li[2]")
	    WebElement hotelLink;

	    @FindBy(id = "Tags")
	    WebElement localityTextBox;
	    
	    @FindBy(xpath="//*[@id='ui-id-1']/li")
	    List<WebElement> localityList;
	    
	    @FindBy(xpath="//*[@id='CheckInDate']")
	    WebElement checkInDate;
	    
	    @FindBy(xpath="//div/table/tbody/tr/td/a[contains(@class,'ui-state-default ui-state-highlight ui-state-active')]")
	    WebElement currentDate;
	    
	    @FindBy(xpath="//*[@id='CheckOutDate]")
	    WebElement checkOutDate;
	    
	    @FindBy(xpath="//div/table/tbody/tr/td/a[contains(@class,'ui-state-default ui-state-active ')]")
	    WebElement activeCheckOutDate;

	    @FindBy(id = "SearchHotelsButton")
	    WebElement searchButton;

	    @FindBy(id = "travellersOnhome")
	    WebElement travellerSelection;
	    
	    @FindBy(xpath="//*[@class='searchSummary']")
	    WebElement searchSummary;
	    
	    public HotelBookingTest(WebDriver driver) {
			this.driver=driver;
		}
	    

	    
	    public void shouldBeAbleToSearchForHotels() throws InterruptedException {
	       
	    	selectHotelOption();
	    	waitFor(1000);
	        enterLocation();
	        waitFor(1000);
	        selectCheckInDate();
	        waitFor(1000);
	        selectCheckOutDate();
	        waitFor(1000);
	        selectOption();
	        waitFor(10000);
	        selectSearch();
	        waitFor(5000);
	        try{
		        Assert.assertTrue(searchSummary.getSize()!=null);
		        System.out.print("TC Pass");
		        }
		        catch (Exception e) {
					e.printStackTrace();
				}
	        
	        
	       

	    }
	    
	    public void selectHotelOption()
	    {
	    	 hotelLink.click();
	    }
	    
	    public void enterLocation()
	    {
	    	 localityTextBox.click();
	    	 localityTextBox.clear();
	    	 localityTextBox.sendKeys("Kempegowda International Airport");
	    	 waitFor(5000);
	    	 localityList.get(1).click();
	    	 waitFor(1000);
	    	
	    }
	    
	    public void selectCheckInDate()
	    {
	    	checkInDate.click();
	    	currentDate.click();
	    }
	    
	    public void selectCheckOutDate()
	    {
	    	
	    	activeCheckOutDate.click();
	    }
	    
	    public void selectOption()
	    {
	    	 Select option= new Select(travellerSelection);
		     option.selectByIndex(1);;
	    }
	    
	    public void selectSearch()
	    {
	    	searchButton.submit();
	    }
	   
}
