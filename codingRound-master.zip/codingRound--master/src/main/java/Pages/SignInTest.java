package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import utilities.Utility;

public class SignInTest extends Utility {
	
	WebDriver driver;
	
    @FindBy(linkText="Your trips")
    WebElement youtTrips;
    
    @FindBy(id="SignIn")
    WebElement signIn;
    
    @FindBy(xpath="//*[@id='signInButton']")
    WebElement signInButton;
    
    @FindBy(id="errors1")
    WebElement errorMsg;
    
    public SignInTest(WebDriver driver)
    {
		this.driver=driver;
	}
    

    
    public void shouldThrowAnErrorIfSignInDetailsAreMissing() {
    	
    	waitFor(1000);
        signInButton.click();
        waitFor(1000);
        String errors1 = errorMsg.getText();
        Assert.assertTrue(errors1.contains("There were errors in your submission"),errors1);
        System.out.print("Tc Pass");
    }
    
    public void selectYourTrips()
    {
    	  waitFor(1000);

          youtTrips.click();
    }
    
    public void selectSignIn()
    {
    	 waitFor(1000);
         signIn.click();
    }

}
