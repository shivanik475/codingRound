package TestCases;

import org.testng.annotations.Test;

import Pages.FlightBookingTest;
import Pages.HotelBookingTest;
import Pages.SignInTest;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;

public class SignInTC{
	
	public static WebDriver driver=null ;
	@BeforeSuite
	 public void setup() {
		    System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\drivers\\chromedriver_win32\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.cleartrip.com/");
	  		}
	 
  	@Test
  	public void SignInPageTest() throws InterruptedException {
	SignInTest signInObj= PageFactory.initElements(driver, SignInTest.class);
	signInObj.selectYourTrips();
	signInObj.selectSignIn();
	driver.switchTo().frame("modal_window");
	   
	     try{
	     signInObj.shouldThrowAnErrorIfSignInDetailsAreMissing();
	     }
	     catch(AssertionError e)
	    	{
	    		
	    		e.printStackTrace();
	    	}
	   	
  }
  	
  	 @AfterSuite
  	  public void tearDown() {
		  
		  driver.quit();;
	  }
 

}
