package TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.FlightBookingTest;

public class FlightBookingTC{
	
	public static WebDriver driver=null ;
	
	@BeforeSuite
	 public void setup() {
		    System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\drivers\\chromedriver_win32\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://www.cleartrip.com/");
	  		}
	
	 @Test
	  public void FightPageTest() {
			 FlightBookingTest flightObj= PageFactory.initElements(driver, FlightBookingTest.class);
			 flightObj.testThatResultsAppearForAOneWayJourney();
		 }
	
	 @AfterSuite
	  public void tearDown() {
		  
		  driver.quit();;
	  }
	 
	 
}
